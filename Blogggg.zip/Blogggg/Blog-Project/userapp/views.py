#from django.core.paginator import Paginator
from django.template import RequestContext
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, render,redirect
from django.http import response
from . models import Post
from .forms import PostForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required,permission_required
from .forms import PostForm

# Create your views here.

@login_required
def create_post(request):
    #logic for creationg a new blog post
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('/home/') 
    else:
        form = PostForm()
    return render(request, 'create_post.html', {'form':form})

@permission_required('blogapp.edit_post', raise_exception=True)
def edit_post(request):
    #logic for editing  blog post
    post = get_object_or_404(Post)
    context = {'post': post}
    return render(request, 'edit_post.html', context)

    #check if the user the author of the post or is an admin
    if request.user == post.author or request.user.is_staff:
        if request.method == 'POST':
            form = PostForm(request.POST, instance=post)
            if form.is_valid():
                form.save()
                messages.success(request, 'Post Updated Successfully..')
                return redirect('post_detail', post_id=post.id)
        else:
            form= PostForm(instance=post)
        return render(request, 'edit_post.html', {'form':form})
    else:
        messages.error(request, 'you do not ave permission to edit this post...')
        return redirect('post_detail', post_id=post.id)

#return redirect('home')

def post_detail(request,pk):
    pk=request.GET.get['pk']
    post=get_object_or_404(Post, pk=pk)
    #post = Post.objects.get()
    return render(request, 'post_details.html', {'post':post})



def userhome(request):
    #paginator = Paginator(posts, 10)
    #page_number = request.GET.get('page')
    #page_obj = paginator.get_page(page_number)
    return render(request, 'userhome.html')