from django.urls import path
from . import views

urlpatterns = [
    path('', views.userhome),
    path('create_post/',views.create_post),
    path('edit_post/',views.edit_post),
    path('post_detail/',views.post_detail),
  
]
