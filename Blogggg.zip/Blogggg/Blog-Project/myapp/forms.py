from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import SubscriptionPlan 

class UserLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Usernmae'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control', 'placeholder':'Password'}))


class SubcriptionPurchaseForm(forms.Form):
    subscription = forms.ModelChoiceField(queryset=SubscriptionPlan.objects.all(), label="Choose a Subcription Plan")
    payment_method = forms.ChoiceField(choices=[('credit_card', 'Credit Card'),('paypal', 'Paypal')],label='Payment Method')

    def process_purchase(self):
        subscription = self.cleaned_data['subscription']
        payment_method = self.cleaned_data['payment_method']



        print(f"Subscription Plan: {subscription}")
        print(f"Payment Method : {payment_method}")