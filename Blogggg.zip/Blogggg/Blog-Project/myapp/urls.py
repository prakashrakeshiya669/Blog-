from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from.import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home),
    path('about/', views.about),
    path('contact/', views.contact),
    path('service/', views.service),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('purchase_subscription/', views.purchase_subscription, name='purchase_subscription'),
    path('mark_subscription_expired/', views.mark_subscription_expired, name="mark_subscription_expired"),
    path('user/',include("userapp.urls")),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
