from django.shortcuts import render,redirect
from . import models
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect 
from . models import SubscriptionPlan, UserProfile
from django.contrib import messages
from .forms import UserLoginForm

# create Views Here
def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def service(request):
    return render(request, 'service.html')


def register(request):
    if request.method =='POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('/login/')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form':form})

def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request=request, data=request.POST)
        if form.is_valid():
            username= form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, 'you have been logged in successfully...')
                return redirect('/user/')
            else:
                messages.error(request, 'Invalid username or password..')
    else:
        form = UserLoginForm()
    return render(request, 'login.html', {'form': form})


def purchase_subscription(request):
    if request.method == 'POST':
        #get the Selected Subcription plan
        subscription_plan = SubscriptionPlan.objects.get(id=plan_id)
        #Check if the user already has an active Subcription
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.subscription_plan:
            messages.warning(request, 'you Already has active subcription..')
            return redirect('profile')
        else:
            #update user profile with the purchase subcription
            user_profile.subscription_plan = subscription_plan
            user_profile.subscription_start_date = datetime.date.today()
            user_profile.subscription_end_date = datetime.date.today() + relativedelta(month=1) #example 1 month
            user_profile.save()
            messages.success(request, 'Subscription Purchased Successfully...')
            return redirect('profile')
    else:
        #if method is not POST, redirect to an appropriate page to handle accordingly
        return render(request, 'purchase_subscription.html')

def mark_subscription_expired(request):
    #logic for marking previous subscription as expired
    if request.method == 'POST':
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.subscription_end_date is not None:
            user_profile.subscription_end_date = None #mark the Subcription end date as none to indicate expiration
            user_profile.save()
            messages.success(request, 'Privius Subscription makred as expired..')
        else:
            messages.warning(request, 'you do not have a active subscription to makrs as expired..')
    else:
        #if method is not POST, redirect to an appropriate page or handle accordinngly
       return render(request, 'mark_subcription_expired.html')